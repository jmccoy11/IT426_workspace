/**
 * CREATED BY:
 * Kevin Locke
 * Jonnathon McCoy (Doc)
 */


package rankings;

import rankings.RankingsCalculator;
import strategies.Selective;
import strategies.Total;
import strategies.Weighted;

public class ReportingConsoleApp
{
    private static RankingsCalculator calc = new RankingsCalculator();

    public static void main(String[] args)
    {
        /*
            1: display a welcome message for the user
            2: Prompt the user for a strategy: TotalStrategy, WeightedStrategy or SelectiveStrategy.
            3: Create the requested strategy object
            4: Create a RankingsCalculator object and print out the reviews using printRankings()
         */


        Console con = new Console();

        // print welcome message
        printWelcomeMessage(con);

        // print menu items
        printMenuItems(con);

        String menuId = con.getString();
        switch(menuId){
            case "1": useTotal();
            break;
            case "2": useWeighted();
            break;
            case "3": useSelective();
            break;
            default: printMenuError(con);
                break;
        }


    }

    private static void printMenuItems(Console con)
    {
        con.print("Please Select a strategy");
        con.print("1. Total");
        con.print("2. Weighted");
        con.print("3. Selective");
    }

    private static void printMenuError(Console con)
    {
        con.print("Please select a valid option");
        printMenuItems(con);
    }

    private static void printWelcomeMessage(Console con)
    {
        con.print("Welcome to the Employee Rankings Application");
        con.print("********************************************");
    }


    private static void useTotal()
    {
        //System.out.println("Total");
        calc.printRankings(new Total(), 2017);
    }

    private static void useWeighted()
    {
        //System.out.println("Weighted");
        calc.printRankings(new Weighted(), 2017);
    }

    private static void useSelective()
    {
        //System.out.println("Selective");
        calc.printRankings(new Selective(), 2017);
    }
}
