package strategies;

import rankings.Review;

import java.util.List;

public class Weighted implements IStrategy
{
    @Override
    public int getScore(int year, List<Review> reviews)
    {
        int sum = 0;

        for(Review review : reviews)
        {
            if(review.getYear() == year)
            {
                for(int i = 0; i < review.getKpis().length; i++)
                {
                    if(i == 1)
                    {
                        sum += review.getKpis()[i] * 2;
                    }
                    else if(i == 3)
                    {
                        sum += review.getKpis()[i] * 3;
                    }
                    else
                    {
                        sum += review.getKpis()[i];
                    }
                }
            }
        }

        return sum;
    }
}
