package strategies;

import rankings.Review;

import java.util.List;

public class Selective implements IStrategy
{
        @Override
        public int getScore(int year, List<Review> reviews)
        {
            int sum = 0;

            for(Review review : reviews)
            {
                if(review.getYear() == year)
                {
                    sum = review.getKpis()[0] + review.getKpis()[2] + review.getKpis()[3];
                }
            }

            return sum;
        }
}
