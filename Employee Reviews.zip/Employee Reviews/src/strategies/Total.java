package strategies;

import rankings.Review;

import java.util.HashMap;
import java.util.List;

public class Total implements IStrategy
{

    @Override
    public int getScore(int year, List<Review> reviews)
    {
        int sum = 0;

        for(Review review : reviews)
        {
            if(review.getYear() == year)
            {
                for(int i = 0; i < review.getKpis().length; i++)
                {
                    sum += review.getKpis()[i];
                }
            }
        }

        return sum;
    }
}
