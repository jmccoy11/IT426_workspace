package model;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import entities.Fruit;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FruitModel.ActionType;

public class FileSaver implements Observer {
    
    @Override
    public void update(Observable observable, Object args) {
        Object[] arguments = (Object[]) args;
        ActionType action = (ActionType) arguments[0];
    
        //is this something I want to respond to here?
        if (action == ActionType.CREATE || action == ActionType.DELETE ||
                action == ActionType.UPDATE) {
            FruitModel model = (FruitModel) observable;
            List<Fruit> fruits = model.getFruits();
    
            try (PrintWriter writer = new PrintWriter(new FileOutputStream("fruits.dat"))) {
                for (Fruit fruit : fruits) {
                    writer.println(fruit);
                }
            } catch (FileNotFoundException e) {
                System.out.println("Something went wrong: " + e.getMessage());
            }
        }
    }
}
